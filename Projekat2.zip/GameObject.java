class GameObject {

    private int x, y, width, height;

 

    public GameObject(int x, int y, int width, int height) {

        setX(x);

        setY(y);

        setWidth(width);

        setHeight(height);

    }

 

    public int getX() { return x; }

    public int getY() { return y; }

    public int getWidth() { return width; }

    public int getHeight() { return height; }

 

    public void setX(int x) { this.x = x; }

    public void setY(int y) { this.y = y; }

 

    public void setWidth(int width) {

        if (width > 0)

            this.width = width;

    }

 

    public void setHeight(int height) {

        if (height > 0)

            this.height = height;

    }

 

    public boolean intersects(GameObject other) {

        return x < other.x + other.width && x + width > other.x

            && y < other.y + other.height && y + height > other.y;

    }

 

    @Override

    public String toString() {

        return String.format("GameObject @ (%d,%d) %dx%d",

                getX(), getY(), getWidth(), getHeight());

    }

}