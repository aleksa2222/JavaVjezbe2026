class BossEnemy extends Enemy {

    public BossEnemy(int x, int y, int width, int height, String type, int damage, int health) {

        super(x, y, width, height, type, damage, health);

    }

 

    @Override

    public int izracunajStetu() {

        return getDamage() * 2;

    }

 

    @Override

    public String toString() {

        return String.format("BossEnemy[%s] @ (%d,%d) %dx%d DMG=%dx2 HP=%d",

                getType(), getX(), getY(), getWidth(), getHeight(), getDamage(), getHealth());

    }

}

