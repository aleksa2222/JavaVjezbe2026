class Enemy extends GameObject {

    private String type;

    private int damage;

    private int health;

 

    public Enemy(int x, int y, int width, int height, String type, int damage, int health) {

        super(x, y, width, height);

        setType(type);

        setDamage(damage);

        setHealth(health);

    }

 

    public String getType() { return type; }

    public int getDamage() { return damage; }

    public int getHealth() { return health; }

 

    public void setType(String type) {

        if (type != null && type.trim().length() > 0)

            this.type = type.trim();

    }

 

    public void setDamage(int damage) {

        if (damage >= 0 && damage <= 100)

            this.damage = damage;

    }

 

    public void setHealth(int health) {

        if (health >= 0 && health <= 100)

            this.health = health;

    }

 

    public int izracunajStetu() {

        return damage;

    }

 

    @Override

    public String toString() {

        return String.format("Enemy[%s] @ (%d,%d) %dx%d DMG=%d HP=%d",

                getType(), getX(), getY(), getWidth(), getHeight(), getDamage(), getHealth());

    }

}