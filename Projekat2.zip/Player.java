class Player extends GameObject {

    private String name;

    private int health;

 

    public Player(int x, int y, int width, int height, String name, int health) {

        super(x, y, width, height);

        setName(name);

        setHealth(health);

    }

 

    public String getName() { return name; }

    public int getHealth() { return health; }

 

    public void setName(String name) {

        if (name == null || name.trim().length() == 0)

            return;

 

        String s = name.trim().toLowerCase();

        StringBuilder sb = new StringBuilder();

        boolean novaRijec = true;

        for (int i = 0; i < s.length(); i++) {

            char c = s.charAt(i);

            if (c == ' ') {

                if (!novaRijec) {

                    sb.append(" ");

                    novaRijec = true;

                }

            } else {

                if (novaRijec)

                    sb.append(s.substring(i, i + 1).toUpperCase());

                else

                    sb.append(c);

                novaRijec = false;

            }

        }

        this.name = sb.toString();

    }

 

    public void setHealth(int health) {

        if (health >= 0 && health <= 100)

            this.health = health;

    }

 

    @Override

    public String toString() {

        return String.format("Player[%s] @ (%d,%d) %dx%d HP=%d",

                getName(), getX(), getY(), getWidth(), getHeight(), getHealth());

    }

}

