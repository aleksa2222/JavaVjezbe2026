
import java.util.ArrayList;

public class Game {

    private Player player;
    private ArrayList<Enemy> enemies = new ArrayList<>();
    private ArrayList<String> eventLog = new ArrayList<>();

    public Game(Player player) {
        this.player = player;
    }

    public boolean checkCollision(Player p, Enemy e) {
        return p.intersects(e);
    }

    public void decreaseHealth(Player p, Enemy e) {
        int stara = p.getHealth();
        int steta = e.izracunajStetu();
        int nova = stara - steta;

        if (nova < 0) {
            nova = 0;
        }

        p.setHealth(nova);

        eventLog.add("HIT: Player by " + e.getType()
                + " for " + steta
                + " -> HP " + stara + " -> " + nova);
    }

    public void addEnemy(Enemy e) {
        enemies.add(e);
        eventLog.add("ADDED: " + e.getType());
    }

    public ArrayList<Enemy> findByType(String query) {
        ArrayList<Enemy> rezultat = new ArrayList<>();

        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);

            if (e.getType().toLowerCase()
                    .contains(query.toLowerCase())) {
                rezultat.add(e);
            }
        }

        return rezultat;
    }

    public ArrayList<Enemy> collidingWithPlayer() {
        ArrayList<Enemy> rezultat = new ArrayList<>();

        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);

            if (checkCollision(player, e)) {
                rezultat.add(e);
            }
        }

        return rezultat;
    }

    public void resolveCollisions() {
        ArrayList<Enemy> sudar = collidingWithPlayer();

        for (int i = 0; i < sudar.size(); i++) {
            decreaseHealth(player, sudar.get(i));
        }
    }

    // Pretvara tekst od cifara u broj, npr. "16" -> 16
    private static int uBroj(String tekst) {
        int rezultat = 0;

        for (int i = 0; i < tekst.length(); i++) {
            rezultat = rezultat * 10 + (tekst.charAt(i) - '0');
        }

        return rezultat;
    }

    // Pravi neprijatelja iz stringa formata:
    // "Goblin;12,5;16x16;20;boss"
    public static Enemy napraviIzStringa(String linija) {
        String ostatak = linija;

        String tip = ostatak.substring(0, ostatak.indexOf(";"));
        ostatak = ostatak.substring(ostatak.indexOf(";") + 1);

        String pozicija = ostatak.substring(0, ostatak.indexOf(";"));
        ostatak = ostatak.substring(ostatak.indexOf(";") + 1);

        String velicina = ostatak.substring(0, ostatak.indexOf(";"));
        ostatak = ostatak.substring(ostatak.indexOf(";") + 1);

        String damageTekst = ostatak.substring(0, ostatak.indexOf(";"));
        String oznaka = ostatak.substring(ostatak.indexOf(";") + 1);

        int x = uBroj(pozicija.substring(0, pozicija.indexOf(",")));
        int y = uBroj(pozicija.substring(pozicija.indexOf(",") + 1));

        int sirina = uBroj(velicina.substring(0, velicina.indexOf("x")));
        int visina = uBroj(velicina.substring(velicina.indexOf("x") + 1));

        int damage = uBroj(damageTekst);

        if (oznaka.equals("boss")) {
            return new BossEnemy(x, y, sirina, visina, tip, damage, 100);
        } else {
            return new MeleeEnemy(x, y, sirina, visina, tip, damage, 100);
        }
    }

    public static void main(String[] args) {
        Player p = new Player(10, 5, 32, 32, "  peTar   petrović ", 85);
        Game game = new Game(p);

        game.addEnemy(new MeleeEnemy(20, 10, 16, 16, "Orc", 10, 50));
        game.addEnemy(napraviIzStringa("Goblin;12,5;16x16;20;boss"));

        ArrayList<Enemy> nadjeni = game.findByType("gob");

        System.out.println("Pronađeno za 'gob': " + nadjeni.size());

        for (int i = 0; i < nadjeni.size(); i++) {
            System.out.println(nadjeni.get(i));
        }

        System.out.println("\nPRIJE KOLIZIJE:");
        System.out.println(p);

        for (int i = 0; i < game.enemies.size(); i++) {
            System.out.println(game.enemies.get(i));
        }

        System.out.println("Sudaraju se: " + game.collidingWithPlayer().size());

        game.resolveCollisions();

        System.out.println("\nPOSLIJE KOLIZIJE:");
        System.out.println(p);

        for (int i = 0; i < game.enemies.size(); i++) {
            System.out.println(game.enemies.get(i));
        }

        System.out.println("\nEVENT LOG:");

        for (int i = 0; i < game.eventLog.size(); i++) {
            System.out.println(game.eventLog.get(i));
        }
    }
}